from VCPlayBot.function.admins import admins
from VCPlayBot.function.admins import get
from VCPlayBot.function.admins import set

__all__ = ["set", "get", "admins"]
